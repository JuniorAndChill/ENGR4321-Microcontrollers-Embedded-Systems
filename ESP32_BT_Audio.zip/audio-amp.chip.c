// Wokwi Custom Chip - Audio Amp Model
// SPDX-License-Identifier: MIT
// Copyright 2026 Daniel Critchlow

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t pin_vcc;
  pin_t pin_gnd;
  pin_t pin_in;
  pin_t pin_gnd_in;
  pin_t pin_out_pos;
  pin_t pin_out_neg;
} chip_state_t;

static void chip_pin_change(void *user_data, pin_t pin, uint32_t value) {
  chip_state_t *chip = (chip_state_t*)user_data;
  // Forward the input state to the positive output
  pin_write(chip->pin_out_pos, value);
  // Invert the input state for the negative output (Differential/BTL)
  pin_write(chip->pin_out_neg, !value);
}

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));

  // 1. Initialize the pins exactly as named in your JSON file
  chip->pin_vcc = pin_init("VCC", INPUT); 
  chip->pin_gnd = pin_init("GND", INPUT);
  chip->pin_in = pin_init("IN", INPUT);
  chip->pin_gnd_in = pin_init("AGND", INPUT); 
  chip->pin_out_pos = pin_init("Out+", OUTPUT);
  chip->pin_out_neg = pin_init("Out-", OUTPUT);

  // 2. Set up the watcher using 'pin_change' as requested by the error message
  const pin_watch_config_t watch_config = {
    .pin_change = chip_pin_change, // FIXED: Changed to match your API version
    .user_data = chip,
  };
  pin_watch(chip->pin_in, &watch_config);

  printf("Audio Amp Chip Initialized.\n");
}